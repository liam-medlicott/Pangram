

public class Main {
	public static void main(String[] args) {
		System.out.println("Pangram");
	
		
		String s ="The quick brown fox jumps over the lazy dog";
		boolean [] mark = new boolean [26];/*boolean set to 26 for letters of the alphabet*/
		boolean pangram = true;
		int index = 0;
		 
		for( int i = 0; i < s.length(); i++) {
			char cur = s.charAt(i);
			/* if and else statement used to iterate through string 
			 * but allowing the use of upper and lower case
			 */
			if(cur >= 'A' && cur <= 'Z') {
				index = cur -'A';
			} else if (cur >= 'a' && cur <= 'z') {
				index = cur - 'a';
				}
			mark[index] = true;
			}
		   for(int i = 0; i < mark.length; i++) {
		       if (mark[i] == false) { 
		    	   pangram = false;
		       }
		   }
		   
		   if(pangram) {
			   System.out.println("well done");
		   } else {
			   System.out.println("no sorry");
		   }
				
				
				
				
				
				
				
			
	}
}
